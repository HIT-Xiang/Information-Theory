# -*- coding: utf-8 -*-
"""
Writer: HIT-Xiang Junjia
Date: 2025 04 26 
"""
import numpy as np
import matplotlib.pyplot as plt
import math

data=np.random.normal(loc=0.0, scale=1.0, size=1000)

counts, bins, _ = plt.hist(data, bins=20,  alpha=0.7, label='Samples')

bin_width = bins[1] - bins[0]                      
x = np.linspace(-4, 4, 1000)  
norm_f = np.zeros(1000)
for i in range(len(x)) :   
   norm_f[i]=math.exp(-x[i]**2 / 2) / math.sqrt(2 * math.pi)

f = norm_f * len(data) * bin_width     
plt.plot(x, f, 'r-', linewidth=2, label='Adjusted F')

plt.xlabel('Value')
plt.ylabel('Frequency')
plt.legend()
plt.show()