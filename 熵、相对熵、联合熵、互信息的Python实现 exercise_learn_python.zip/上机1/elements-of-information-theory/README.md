# 信息论基础 Elements of Information Theory

## MWORKS下载安装
MWORKS.Syslab 2023a：https://www.tongyuan.cc/download

## 上机作业
1. 熵、相对熵、联合熵、互信息的Python实现: exercise_learn_python, 2025.05.06 11:59pm 提交至 yaoli0508@hit.edu.cn 5分

