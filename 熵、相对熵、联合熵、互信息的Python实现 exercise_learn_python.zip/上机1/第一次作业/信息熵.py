# -*- coding: utf-8 -*-
"""
Writer: HIT-Xiang Junjia
Date: 2025 04 26 
"""
import numpy as np
import math
import scipy

def log(x):
    return math.log(x, 2)

def entropy(px):
    # return the entropy of the random variable 'x' with probability distribution 'px'      
    # e.g. px = [1/2, 1/2,  0]
    h = np.zeros(len(px))
    for i in range(len(px)):
        if (px[i]>0):
            h[i] = px[i] * log(px[i])            
        else:
            continue       

    ans = - np.array(h).sum()
    
    return ans

def relative_entropy(px, qx):
    # return the relative entropy of the random variable 'x' with probability distribution 'px' and 'qx' 
    # e.g. px = [1/2, 1/2,  0], qx = [5/36, 1/3, 19/36]
       h = np.zeros(len(px))

       for i in range(len(px)):
        if (px[i]>0):
            h[i] = px[i] * log(px[i]/qx[i])            
        else:
            continue       

       ans = np.array(h).sum()

       return ans

def joint_entropy(pxy):
    # return the joint entropy of the random variable 'x' and 'y' with joint p.d. 'pxy'
    # e.g. qxy = [[1/18, 1/12], [1/18, 5/18], [5/18, 1/4]]

    h = 0.0
    for row in pxy:
        for p in row:
            if p > 0:
                h += p * log(p)
    
    ans = -h

    return ans
    

def mutual_infomation(px, py, pxy):
    # return the mutual information of I(x;y)
    hx = entropy(px)
    hy = entropy(py)
    hxy = joint_entropy(pxy)

    ans = hx + hy - hxy

    return ans