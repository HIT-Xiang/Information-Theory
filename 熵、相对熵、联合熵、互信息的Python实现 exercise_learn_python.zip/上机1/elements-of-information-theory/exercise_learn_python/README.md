# 安装Python

## ANACONDA
### 安装
https://www.anaconda.com/docs/getting-started/anaconda/install

### 成功安装
![Alt text](../images/anaconda.jpg?raw=true "anaconda")

### Spyder
![Alt text](../images/spyder.jpg?raw=true "spyder")

### Jupyter Notebook
![Alt text](../images/notebook.jpg?raw=true "notebook")

## 其他编译器
### PyCharm
https://www.jetbrains.com/pycharm/
### VS Code
https://code.visualstudio.com
### Atom
https://atom-editor.cc
### NotePad++
https://notepad-plus-plus.org
